package com.company.ProGUI;

public interface IMenu {

    public int id();

    public String nazwa();

    public String opisDania();

    public double cena();

    public boolean dostep();
}
