package com.company.ProGUI;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class RefreshMenu implements Runnable{
    static ArrayList<Desert> Menu_desert = Menu.Menu_desert;
    static ArrayList<PierwszeDanie> Menu_Pdanie = Menu.Menu_Pdanie;
    static ArrayList<DrugieDanie> Menu_Ddanie = Menu.Menu_Ddanie;
    static ArrayList<Napoje> Menu_napoj = Menu.Menu_napoj;
    static String wyznacznik = " ";
    DataOutputStream outputStream = null;
    File Menu_Pdanie_FilePath = new File("Menu_Pdanie.txt");
    File Menu_Ddanie_FilePath = new File("Menu_Ddanie.txt");
    File Menu_Desert_FilePath = new File("Menu_Desert.txt");
    File Menu_Napoje_FilePath = new File("Menu_Napoje.txt");

    @Override
    public void run() {
        while(true) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if(Objects.equals(wyznacznik, "deser")){
                try {
                    FileWriter desery = new FileWriter(Menu_Desert_FilePath, false);
                    desery.write(String.valueOf(Menu_desert.get(Menu_desert.size()-1)));
                    desery.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(Objects.equals(wyznacznik, "pierwsze danie")){
                try {
                    FileWriter pierwszeDanie = new FileWriter(Menu_Pdanie_FilePath, false);
                    pierwszeDanie.write(String.valueOf(Menu_Pdanie.get(Menu_Pdanie.size()-1)));
                    pierwszeDanie.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(Objects.equals(wyznacznik, "drugie danie")){
                try {
                    FileWriter drugieDanie = new FileWriter(Menu_Ddanie_FilePath, false);
                    drugieDanie.write(String.valueOf(Menu_Ddanie.get(Menu_Ddanie.size()-1)));
                    drugieDanie.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(Objects.equals(wyznacznik, "napoj")) {
                try {
                    FileWriter napoj = new FileWriter(Menu_Napoje_FilePath, false);
                    napoj.write(String.valueOf(Menu_napoj.get(Menu_napoj.size()-1)));
                    napoj.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if(Objects.equals(wyznacznik, " ")){
                try {
                    FileWriter drugieDanie = new FileWriter(Menu_Ddanie_FilePath, false);
                    FileWriter napoj = new FileWriter(Menu_Napoje_FilePath, false);
                    FileWriter pierwszeDanie = new FileWriter(Menu_Pdanie_FilePath, false);
                    FileWriter desery = new FileWriter(Menu_Desert_FilePath, false);
                    for (int i = 0; i < Menu_Ddanie.size(); i++) {
                        drugieDanie.write(String.valueOf(Menu_Ddanie.get(i)));
                        napoj.write(String.valueOf(Menu_napoj.get(i)));
                        pierwszeDanie.write(String.valueOf(Menu_Pdanie.get(i)));
                        desery.write(String.valueOf(Menu_desert.get(i)));
                    }
                    drugieDanie.close();
                    napoj.close();
                    pierwszeDanie.close();
                    desery.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void setWyznacznik(String wyznacznik) {
        RefreshMenu.wyznacznik = wyznacznik;
    }
}
