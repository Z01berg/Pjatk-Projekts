package com.company.ProGUI;

public enum StatusZamowien {
    realizacja,
    dostawa,
    zrealizowane
}
