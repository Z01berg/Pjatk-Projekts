package com.company.ProGUI;

public class Kucharz implements IPracownik{

    int id;
    String imie,nazwisko;
    int numertelf;
    double napiwek;

    public Kucharz(int id, String imie, String nazwisko, int numertelf, double napiwek){
        this.id= id;
        this.imie=imie;
        this.nazwisko=nazwisko;
        this.numertelf=numertelf;
        this.napiwek=napiwek;
    }

    @Override
    public int id() {
        return id;
    }

    @Override
    public String imie() {
        return imie;
    }

    @Override
    public String nazwisko() {
        return nazwisko;
    }

    @Override
    public int numertelf() {
        return numertelf;
    }

    @Override
    public double napiwek() {
        return napiwek;
    }
}
