package com.company.ProGUI;

public interface IPracownik {

    public int id();

    public String imie();

    public String nazwisko();

    public int numertelf();

    public double napiwek();

}
