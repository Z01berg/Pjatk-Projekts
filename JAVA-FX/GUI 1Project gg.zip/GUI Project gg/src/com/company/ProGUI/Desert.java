package com.company.ProGUI;

public class Desert implements IMenu{

int id;
String nazwa,opisDania;
double cena;
boolean dostep;

    public Desert(int id, String nazwa, String opisDania, double cena, boolean dostep){
        this.id= id;
        this.nazwa=nazwa;
        this.opisDania=opisDania;
        this.cena=cena;
        this.dostep=dostep;
    }
    @Override
    public int id() {
        return id;
    }

    @Override
    public String nazwa() {
        return nazwa;
    }

    @Override
    public String opisDania() {
        return opisDania;
    }

    @Override
    public double cena() {
        return cena;
    }

    @Override
    public boolean dostep() {
        return dostep;
    }

    public void setDostep(boolean dostep) {
        this.dostep = dostep;
    }
}
