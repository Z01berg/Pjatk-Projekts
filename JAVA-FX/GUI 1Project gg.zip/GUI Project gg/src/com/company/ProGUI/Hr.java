package com.company.ProGUI;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.SortedMap;

public class Hr implements Runnable {
    int start = 0;
    static List<Zamowienie> zamowienia = new ArrayList<>();


    @Override
    public void run() {
        Menu.dodajMenu();
        Pracowniki.dodajListePracownikow();

        Scanner scan = new Scanner(System.in);
        while (true) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (start == 1) {
                System.out.println("RESTAURACJA ▓ OTWARTA ▓");
                System.out.println("1 - Dodaj zamowienie dostawa");
                System.out.println("2 - Dodaj zamowienie na miejscu");
                System.out.println("3 - Usun produkt z menu");
                System.out.println("4 - Dodaj produkt do menu");
                System.out.println("5 - Dodaj pracownika");
                System.out.println("6 - Usun pracownika");
                System.out.println("7 - Zmien dostepnosc produktu w menu");
                System.out.println("8 - Wyswietl liste zamowien");
                System.out.println("9 - Wyswietl utarg");
                System.out.println("10 - Wstrzymaj prace");
            } else if (start == 0) {
                System.out.println("RESTAURACJA ▓ ZAMKNIETA ▓");
                System.out.println("10 - Rozpoczni prace");
            }


            int opcja = scan.nextInt();

            if (opcja == 1 && start == 1) {

                System.out.println("1 - Pierwsze danie    2 - Drugie danie    3 - Napoje    4 - Desery");
                int md = scan.nextInt();

                if (md == 1) {
                    zamowienia.get(zamowienia.size() - 1).wyswietlMenuPierwszeDanie();
                    System.out.println("\n" + "=====================================================================" + "\n");

                    zamowienia.get(zamowienia.size() - 1).zamowienie_z_dostawa_Pdanie();

                } else if (md == 2) {
                    zamowienia.get(zamowienia.size() - 1).wyswietlMenuDrugieDanie();
                    System.out.println("\n" + "=====================================================================" + "\n");

                    zamowienia.get(zamowienia.size() - 1).zamowienie_z_dostawa_Ddanie();

                } else if (md == 3) {
                    zamowienia.get(zamowienia.size() - 1).wyswietlMenuNapoje();
                    System.out.println("\n" + "=====================================================================" + "\n");

                    zamowienia.get(zamowienia.size() - 1).zamowienie_z_dostawa_napoje();

                } else if (md == 4) {
                    zamowienia.get(zamowienia.size() - 1).wyswietlMenuDeserow();
                    System.out.println("\n" + "=====================================================================" + "\n");

                    zamowienia.get(zamowienia.size() - 1).zamowienie_z_dostawa_desert();

                } else {
                    System.out.println("Zle podana wartosc");
                }

            } else if (opcja == 2 && start == 1) {

                zamowienia.get(zamowienia.size() - 1).getNumer_stolika();

                System.out.println("1 - Pierwsze danie    2 - Drugie danie    3 - Napoje    4 - Desery");
                int md = scan.nextInt();

                if (md == 1) {
                    zamowienia.get(zamowienia.size() - 1).wyswietlMenuPierwszeDanie();
                    System.out.println("\n" + "=====================================================================" + "\n");

                    zamowienia.get(zamowienia.size() - 1).zamowienie_na_miejscu_Pdanie();

                } else if (md == 2) {
                    zamowienia.get(zamowienia.size() - 1).wyswietlMenuDrugieDanie();
                    System.out.println("\n" + "=====================================================================" + "\n");

                    zamowienia.get(zamowienia.size() - 1).zamowienie_na_miejscu_Ddanie();

                } else if (md == 3) {
                    zamowienia.get(zamowienia.size() - 1).wyswietlMenuNapoje();
                    System.out.println("\n" + "=====================================================================" + "\n");

                    zamowienia.get(zamowienia.size() - 1).zamowienie_na_miejscu_Napoje();

                } else if (md == 4) {
                    zamowienia.get(zamowienia.size() - 1).wyswietlMenuDeserow();
                    System.out.println("\n" + "=====================================================================" + "\n");

                    zamowienia.get(zamowienia.size() - 1).zamowienie_na_miejscu_Desert();

                } else {
                    System.out.println("Zle podana wartosc");
                }

            } else if (opcja == 3 && start == 1) {

                System.out.println("1 - usun Pierwsze danie    2 - usun Drugie danie    3 - usun dodaj Napoje    4 - usun dodaj Desery");
                int md = scan.nextInt();

                if (md == 1) {
                    zamowienia.get(zamowienia.size() - 1).wyswietlMenuPierwszeDanie();
                    System.out.println("\n" + "=====================================================================" + "\n");

                    zamowienia.get(zamowienia.size() - 1).usun_z_Pdanie();

                } else if (md == 2) {
                    zamowienia.get(zamowienia.size() - 1).wyswietlMenuDrugieDanie();
                    System.out.println("\n" + "=====================================================================" + "\n");

                    zamowienia.get(zamowienia.size() - 1).usun_z_Ddanie();

                } else if (md == 3) {
                    zamowienia.get(zamowienia.size() - 1).wyswietlMenuNapoje();
                    System.out.println("\n" + "=====================================================================" + "\n");

                    zamowienia.get(zamowienia.size() - 1).usun_z_Napoje();

                } else if (md == 4) {
                    zamowienia.get(zamowienia.size() - 1).wyswietlMenuDeserow();
                    System.out.println("\n" + "=====================================================================" + "\n");

                    zamowienia.get(zamowienia.size() - 1).usun_z_Desert();

                } else {
                    System.out.println("Zle podana wartosc");
                }


            } else if (opcja == 4 && start == 1) {

                System.out.println("1 - dodaj Pierwsze danie    2 - dodaj Drugie danie    3 - dodaj Napoje    4 - dodaj Desery");
                int md = scan.nextInt();

                if (md == 1) {
                    zamowienia.get(zamowienia.size() - 1).dodaj_pierwszeDanie();

                } else if (md == 2) {
                    zamowienia.get(zamowienia.size() - 1).dodaj_drugieDanie();

                } else if (md == 3) {
                    zamowienia.get(zamowienia.size() - 1).dodaj_napoje();

                } else if (md == 4) {
                    zamowienia.get(zamowienia.size() - 1).dodaj_desert();

                } else {
                    System.out.println("Zle podana wartosc");
                }

            } else if (opcja == 5 && start == 1) {

                System.out.println("1 - dodaj Kucharza    2 - dodaj Kelnera    3 - dodaj Dostawa");
                int md = scan.nextInt();

                if (md == 1) {
                    //dodaj_kucharza()

                    //  Pracowniki.get(size()-1).dodaj_kucharza();
                } else if (md == 2) {
                    //dodaj_kelner()

                } else if (md == 3) {
                    //dodaj_dostawca()

                } else {
                    System.out.println("Zle podana wartosc");
                }

            } else if (opcja == 6 && start == 1) {

                System.out.println("1 - usun Kucharza    2 - usun Kelnera    3 - usun Dostawa");
                int md = scan.nextInt();

                if (md == 1) {
                    //getLista_kucharz()

                    //usun_z_Kucharz()

                } else if (md == 2) {
                    //getLista_kelner()

                    //usun_z_Kelner()

                } else if (md == 3) {
                    //getLista_dostawa()

                    //usun_z_Dostawa()

                } else {
                    System.out.println("Zle podana wartosc");
                }

            } else if (opcja == 7 && start == 1) {
                zamowienia.get(zamowienia.size() - 1).wyswietlMenuDeserow();
                zamowienia.get(zamowienia.size() - 1).wyswietlMenuPierwszeDanie();
                zamowienia.get(zamowienia.size() - 1).wyswietlMenuDrugieDanie();
                zamowienia.get(zamowienia.size() - 1).wyswietlMenuNapoje();

                zamowienia.get(zamowienia.size() - 1).zmianaDostepnosci();

            } else if (opcja == 8 && start == 1) {
                for (int i = 0; i < zamowienia.size(); i++) {
                    System.out.println(zamowienia.get(i));
                }
            } else if (opcja == 9 && start == 1) {
                zamowienia.get(zamowienia.size() - 1).pokaz_utarg();

            } else if (opcja == 10) {

                if (start == 0) {
                    System.out.println("Otwieramy sie");
                    //poczatek pracy
                    start = 1;
                } else if (start == 1) {
                    System.out.println("Zamykamy sie");
                    Thread.currentThread().stop();
                    start = 0;
                }

            } else {
                System.out.println("Zle podana wartosc lub restauracja zamkneita");
            }

            /**
             *               zamowienia.add()
             *               if
             *             System.out.println("1 - dodaj pierwsze danie do zamowienia");
             *             System.out.println("2 - Dodaj zamowienie na miejscu");
             *             System.out.println("3 - Usun produkt z menu");
             *             System.out.println("4 - Dodaj produkt do menu");
             *             if(1){
             *             zamowienia.get(size()-1).zamowienie_na_miejscu_PDanie;
             *             }
             */
        }
    }

    public static List<Zamowienie> getZamowienia() {
        return zamowienia;
    }
}
