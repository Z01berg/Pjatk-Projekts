package com.company.ProGUI;

public class Zamowienie extends Menu  {
    Menu menu = new Menu();
    String adres;
    int index;
    int numer_stolika = (int) (Math.random()*10);
    StatusZamowien statusZamowienia;

    double cena_napoje1 = 0;
    double cena_napoje2 = 0;
    double cena_Ddanie1 = 0;
    double cena_Ddanie2 = 0;
    double cena_desert1 = 0;
    double cena_desert2 = 0;
    double cena_Pdanie1 = 0;
    double cena_Pdanie2 = 0;


    public int getNumer_stolika() {
        int numer_stolika;

        System.out.println("Prosze podać numer stolika (od 1-30)");

        do {
            numer_stolika =scan.nextInt();
            if (numer_stolika>30 || numer_stolika<1){
                System.out.println("Zle podana wartosc");
            }
        }while (numer_stolika>30 || numer_stolika<1);

        return numer_stolika;
    }

    public double zamowienie_z_dostawa_Pdanie() {

        System.out.println("Prosze podac index");
        index = scan.nextInt();

        System.out.println("Prosze podac adres");
        adres = scan.nextLine();

        PierwszeDanie zupa = null;
        for (int i = 0; i < Menu_Pdanie.size(); i++) {
            if (Menu_Pdanie.isEmpty()) {
                System.out.println("Menu zup jest puste");
            } else if (Menu_Pdanie.contains(i)) {
                zupa = Menu_Pdanie.get(i);
                cena_Pdanie2 = zupa.cena();
            }
        }
        System.out.println("Adres dostawy: " + adres
                + "\nZostała zamówiona zupa:  " + zupa
                + "\nKoszt: " + cena_Pdanie2);
        return cena_napoje1;
    }
    public double zamowienie_z_dostawa_Ddanie(){

        System.out.println("Prosze podac index");
        index = scan.nextInt();

        System.out.println("Prosze podac adres");
        adres = scan.nextLine();

        DrugieDanie drugieD = null;
        for(int i = 0; i< Menu_Ddanie.size();i++){
            if(Menu_Ddanie.isEmpty()){
                System.out.println("Menu zup jest puste");
            }else if(Menu_Ddanie.contains(i)){
                drugieD = Menu_Ddanie.get(i);
                cena_Ddanie2 = drugieD.cena();
            }
        }
        System.out.println("Adres dostawy: " + adres
                + "\n Zostało zamówione: " + drugieD
                + "\n Koszt: " + cena_Ddanie2);
        return cena_Ddanie2;
    }
    public double zamowienie_z_dostawa_desert(){

        System.out.println("Prosze podac index");
        index = scan.nextInt();

        System.out.println("Prosze podac adres");
        adres = scan.nextLine();

        Desert deser = null;
        for(int i = 0; i< Menu_desert.size();i++){
            if(Menu_desert.isEmpty()){
                System.out.println("Menu deserów jest puste");
            }else if(Menu_desert.contains(i)){
                deser = Menu_desert.get(i);
                cena_desert1 = deser.cena();
            }
        }
        System.out.println("Adres dostawy: " + adres
                + "\n Został zamówiony deser: " + deser
                + "\n Koszt : " + cena_desert1);
        return cena_desert1;
    }
    public double zamowienie_z_dostawa_napoje(){

        System.out.println("Prosze podac index");
        index = scan.nextInt();

        System.out.println("Prosze podac adres");
        adres = scan.nextLine();

        Napoje napoj = null;
        for(int i = 0; i< Menu_napoj.size();i++){
            if(Menu_napoj.isEmpty()){
                System.out.println("Menu napojów jest puste");
            }else if(Menu_napoj.contains(i)){
                napoj = Menu_napoj.get(i);
                cena_napoje2 = napoj.cena();
            }
        }
        System.out.println("Adres dostawy: " + adres
                + "\n Zostało zamówione:" + napoj
                + "\n Koszt : " + cena_napoje2);
        return cena_napoje2;
    }
    public double zamowienie_na_miejscu_Pdanie(){

        System.out.println("Prosze podac index");
        index = scan.nextInt();

        PierwszeDanie zupa = null;
        for (int i = 0; i < Menu_Pdanie.size(); i++) {
            if (Menu_Pdanie.isEmpty()) {
                System.out.println("Menu zup jest puste");
            } else if (Menu_Pdanie.contains(i)) {
                zupa = Menu_Pdanie.get(i);
                cena_Pdanie1 = zupa.cena();
            }
        }
        System.out.println("Twoj numer stolika to: " + numer_stolika
                + "\nZostała zamówiona zupa:  " + zupa
                + "\nKoszt: " + cena_Pdanie1);
        return cena_Pdanie1;
    }
    public double zamowienie_na_miejscu_Ddanie(){

        System.out.println("Prosze podac index");
        index = scan.nextInt();

        DrugieDanie drugieD = null;
        for(int i = 0; i< Menu_Ddanie.size();i++){
            if(Menu_Ddanie.isEmpty()){
                System.out.println("Menu zup jest puste");
            }else if(Menu_Ddanie.contains(i)){
                drugieD = Menu_Ddanie.get(i);
                cena_Ddanie1 = drugieD.cena();
            }
        }
        System.out.println("Twoj numer stolika to: " + numer_stolika
                + "\nZostało zamówione: " + drugieD
                + "\nKoszt: " + cena_Ddanie1);
        return cena_Ddanie1;
    }
    public double zamowienie_na_miejscu_Desert(){

        System.out.println("Prosze podac index");
        index = scan.nextInt();

        Desert deser = null;
        for(int i = 0; i< Menu_desert.size();i++){
            if(Menu_desert.isEmpty()){
                System.out.println("Menu deserów jest puste");
            }else if(Menu_desert.contains(i)){
                deser = Menu_desert.get(i);
                cena_desert2 = deser.cena();
            }
        }
        System.out.println("Numer stolika: " + numer_stolika
                + "\n Został zamówiony deser: " + deser
                + "\n Koszt: " + cena_desert2);
        return cena_desert2;
    }
    public double zamowienie_na_miejscu_Napoje(){

        System.out.println("Prosze podac index");
        index = scan.nextInt();

        Napoje napoj = null;
        for(int i = 0; i< Menu_napoj.size();i++){
            if(Menu_napoj.isEmpty()){
                System.out.println("Menu napojów jest puste");
            }else if(Menu_napoj.contains(i)){
                napoj = Menu_napoj.get(i);
                cena_napoje1 = napoj.cena();
            }
        }
        System.out.println("Numer stolika: " + numer_stolika
                + "\n Zostało zamówione:" + napoj
                + "\n Koszt: " + cena_napoje1);
        return cena_napoje1;
    }
    public void pokaz_utarg(){
        System.out.println(cena_Pdanie1 + cena_Pdanie1
                + cena_Ddanie2 + cena_Ddanie1
                + cena_desert1 + cena_Ddanie1
                + cena_napoje2 + cena_napoje1);
    }

    public void setStatusZamowienia(StatusZamowien statusZamowienia) {
        this.statusZamowienia = statusZamowienia;
    }
}
