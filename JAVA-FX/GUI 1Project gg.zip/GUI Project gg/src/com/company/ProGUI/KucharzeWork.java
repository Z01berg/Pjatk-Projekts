package com.company.ProGUI;

import java.util.List;

public class KucharzeWork implements Runnable {
    List<Zamowienie> zamowienia = Hr.getZamowienia();
    int indexzamownia;
    @Override
    public void run() {
        if(zamowienia.size() > 0){
            indexzamownia = zamowienia.size()-1;
            while(true) {
                try {
                    Thread.sleep(30000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                zamowienia.get(1).setStatusZamowienia(StatusZamowien.dostawa);
            }
        }
    }
}
