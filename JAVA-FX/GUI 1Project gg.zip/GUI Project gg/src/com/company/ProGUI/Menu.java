package com.company.ProGUI;

import java.io.DataOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;


public class Menu {

    static ArrayList<Desert> Menu_desert = new ArrayList<>();
    static ArrayList<PierwszeDanie> Menu_Pdanie = new ArrayList<PierwszeDanie>();
    static ArrayList<DrugieDanie> Menu_Ddanie = new ArrayList<DrugieDanie>();
    static ArrayList<Napoje> Menu_napoj = new ArrayList<Napoje>();

    static Desert panna_cotta = new Desert(1, "Panna Cotta", "Panna cotta to północnowłoski deser składający się z podgrzanej śmietanki z żelatyną oraz różnych, najczęściej owocowych, dodatków. W języku włoskim panna cotta oznacza ''gotowaną śmietankę'' i nawiązuje do sposobu przygotowania tego dania.", 15.75, true);
    static Desert lody = new Desert(13, "Lody", "zamrożony deser, który uzyskuje się poprzez zamrażanie masy uzyskanej z produktów mlecznych (lody mleczne) bądź wody (lody wodne) z dodatkami smakowymi (dodatki tradycyjne – owoce czy czekolada lub nietradycyjne – warzywne czy nawet mięsne), lub zamrażanie masy złożonej z owoców, cukru i wody (sorbet).", 6.00, true);
    static Desert sernik = new Desert(2, "Sernik", "rodzaj ciasta deserowego lub deseru uformowanego na kształt ciasta, którego głównym składnikiem jest biały ser.", 5.00, true);
    static Desert tiramisu = new Desert(14, "Tiramisu", "od tira mi sù 'popraw mi humor', dosł. 'podnieś mnie') – deser złożony z warstwy biszkoptu nasączonej bardzo mocną kawą espresso, na którą nakłada się warstwę kremu z sera mascarpone, żółtek jaj kurzych i cukru, a całość posypuje się warstwą grubo zmielonych płatków gorzkiej czekolady.", 78.50, false);
    static Desert lava_cake = new Desert(3, "Lava Cake", "czyli fondant czekoladowy nazywany też ciastem lawowym to prosty czekoladowy deser który przypadnie do gustu wszystkim miłośnikom czekolady", 50.00, true);

    static PierwszeDanie zupa_pomidorowa = new PierwszeDanie(4, "Zupa Pomidorowa", "upa przygotowywana na bazie rosołu lub bulionu z warzyw. Głównym składnikiem dania są świeże pomidory lub koncentrat pomidorowy. Zupę podaje się z makaronem lub ryżem, lanym ciastem czy tzw. zacierką.", 20.25, true);
    static PierwszeDanie zupa_kapusniak = new PierwszeDanie(17, "Kapusniak", "Klasyczna, polska zupa z kiszonej kapusty, z ziemniakami i warzywami na wywarze z żeberek. Jest sycąca, rozgrzewająca, aromatyczna i kwaskowata. Może stanowić samodzielne danie, jeśli dodamy do niej kawałki mięsa z wywaru.", 40.00, false);
    static PierwszeDanie zupa_barszcz = new PierwszeDanie(5, "Barszcz", "zupa sporządzana z buraków ćwikłowych, na soku buraczanym poddanym fermentacji mlekowej (ukwaszonym) lub zagęszczonym soku buraczanym, na wywarze jarskim z dodatkiem dużej ilości przypraw. Największą popularnością cieszy się tradycyjny, domowy barszcz czerwony zabielany z ziemniakami.", 75.99, true);
    static PierwszeDanie zupa_serna = new PierwszeDanie(18, "Serna zupa", "Zamiast ziemniaków rosół można podać z kluskami lanymi, makaronem lub czysty do picia. Tak przygotowany rosół to najlepsza baza pod zupy", 20.25, false);
    static PierwszeDanie zupa_grochowa = new PierwszeDanie(6, "Zupa Grochowa", "Jak sama nazwa wskazuje, to zupa na bazie łuskanego grochu, z dodatkiem warzyw (ziemniaków, cebuli i czosnku), przypraw (majeranek, liście laurowe, ziele angielskie, sól i pieprz) oraz solidną porcją mięsa (wędzony boczek, kiełbasa).", 40.50, true);

    static DrugieDanie ziemniaki_mieso = new DrugieDanie(7, "Ziemniaki z Miesem", "Bardzo smaczne ziemniaczki z mięskiem i cebulką. Tak przygotowane ziemniaki pieczemy w piekarniku. Łatwe w przygotowaniu", 80.00, true);
    static DrugieDanie sushi = new DrugieDanie(19, "Sushi", "potrawa japońska złożona z gotowanego ryżu zaprawionego octem ryżowym (su) oraz różnych dodatków w postaci, przeważnie surowych: owoców morza, wodorostów nori, kawałków ryb, warzyw, grzybów, a także omletu japońskiego (tamago-yaki), tofu, ziarna sezamowego (goma).", 65.00, true);
    static DrugieDanie la_pasta = new DrugieDanie(8, "Pasta", "Makaron, pasta, spaghetti… wszystkie te słowa kojarzą się z pysznymi daniami, włoskim temperamentem, kolacją przy kieliszku dobrego wina, wiórkami parmezanu", 62.20, false);
    static DrugieDanie Onigiri = new DrugieDanie(20, "Onigiri", "jest zrobione z ryżu uformowanego w trójkątny lub owalny kształt, czasami zawinięte w nori. Potrawa ta jest nadziewana m.in. marynowaną morelą japońską (umeboshi), ikrą, krewetkami, rybą (tuńczyk, keta), itp. Farsz jest zazwyczaj słony, aby ochronić ryż przed zepsuciem.", 45.00, true);
    static DrugieDanie pizza = new DrugieDanie(9, "Pizza", " potrawa kuchni włoskiej, obecnie szeroko rozpowszechniona na całym świecie. Jest to płaski placek z ciasta drożdżowego (focaccia), z sosem pomidorowym, posypany tartym serem (najczęściej jest to mozzarella) i ziołami, pieczony w bardzo mocno nagrzanym piecu", 100.00, true);

    static Napoje coca_cola = new Napoje(10, "Coca-Cola", "marka napoju gazowanego przedsiębiorstwa The Coca-Cola Company. Powstała pod koniec XIX wieku i jest jedną z popularnych marek na świecie. Od 1960 roku kształt butelki jest prawnie zastrzeżony.", 66.99, true);
    static Napoje woda = new Napoje(15, "Woda", "to substancja chemiczna, która składa się z ogromnych ilości przytulonych do siebie malusieńkich cząsteczek. Każda z nich składa się z dwóch atomów wodoru i jednego atomu tlenu. Symbolem wodoru jest H, symbolem tlenu jest O, dlatego o wodzie mówimy H2O.", 3.00, true);
    static Napoje sok = new Napoje(11, "Sok", "produkt otrzymany z dojrzałych, świeżych lub przechowywanych owoców lub warzyw, jednego lub większej liczby gatunków, posiadający barwę, smak i zapach charakterystyczny dla soku z owoców lub warzyw, z których pochodzą, zdolny do fermentacji, lecz niesfermentowany.", 5.45, false);
    static Napoje lemonad = new Napoje(16, "Lemonad", "Kostki lodu włożyć do szklanki highball, następnie wlać sok z cytryny, syrop oraz wodę. Wymieszać dokładnie łyżką barową przez około 8-10 sekund.", 5.00, true);
    static Napoje energetyk = new Napoje(12, "Energetyk", "pobudzający, przeważnie gazowany napój bezalkoholowy, z reguły zawierający kofeinę, taurynę i guaranę (źródło kofeiny). Bywa mylony z napojami izotonicznymi, które mają inne działanie.", 50.00, true);

    Scanner scan = new Scanner(System.in);
    int nr = 21;


    public static void dodajMenu() {
        Menu_desert.add(panna_cotta);
        Menu_desert.add(sernik);
        Menu_desert.add(lava_cake);
        Menu_desert.add(lody);
        Menu_desert.add(tiramisu);
        Menu_Pdanie.add(zupa_pomidorowa);
        Menu_Pdanie.add(zupa_barszcz);
        Menu_Pdanie.add(zupa_grochowa);
        Menu_Pdanie.add(zupa_serna);
        Menu_Pdanie.add(zupa_kapusniak);
        Menu_Ddanie.add(ziemniaki_mieso);
        Menu_Ddanie.add(la_pasta);
        Menu_Ddanie.add(pizza);
        Menu_Ddanie.add(Onigiri);
        Menu_Ddanie.add(sushi);
        Menu_napoj.add(coca_cola);
        Menu_napoj.add(sok);
        Menu_napoj.add(energetyk);
        Menu_napoj.add(woda);
        Menu_napoj.add(lemonad);
    }

    public void zmianaDostepnosci() {
        System.out.println("Co chcesz zmienic : deser, napoj, pierwsze danie, drugie danie");
        String out = scan.nextLine();
        if(out == "deser"){
            System.out.println("Podaj który jest to deser : ");
            int index = scan.nextInt();
            if(index <= Menu_desert.size()-1){
                if (Menu_desert.get(index).dostep()) {
                    Menu_desert.get(index).setDostep(false);
                } else {
                    Menu_desert.get(index).setDostep(true);
                }
            }
        }
        if(out == "napoj"){
            System.out.println("Podaj który jest to napoj : ");
            int index = scan.nextInt();
            if(index <= Menu_napoj.size()-1){
                if (Menu_napoj.get(index).dostep()) {
                    Menu_napoj.get(index).setDostep(false);
                } else {
                    Menu_napoj.get(index).setDostep(true);
                }
            }
        }
        if(out == "pierwsze danie"){
            System.out.println("Podaj które jest to pierwsze danie : ");
            int index = scan.nextInt();
            if(index <= Menu_Pdanie.size()-1){
                if (Menu_Pdanie.get(index).dostep()) {
                    Menu_Pdanie.get(index).setDostep(false);
                } else {
                    Menu_Pdanie.get(index).setDostep(true);
                }
            }
        }
        if(out == "deser"){
            System.out.println("Podaj które jest to drugie danie : ");
            int index = scan.nextInt();
            if(index <= Menu_Ddanie.size()-1){
                if (Menu_Ddanie.get(index).dostep()) {
                    Menu_Ddanie.get(index).setDostep(false);
                } else {
                    Menu_Ddanie.get(index).setDostep(true);
                }
            }
        }
    }

    public void czy_dostepne_pierwszeD(int id) {
        if(Menu_Pdanie.get(id).dostep()) {
            System.out.println("Jest dostepne");
        } else {
            System.out.println("Nie jest dostepne");
        }
    }

    public void czy_dostepne_drugieD(int id) {
        if(Menu_Ddanie.get(id).dostep()) {
            System.out.println("Jest dostepne");
        } else {
            System.out.println("Nie jest dostepne");
        }
    }

    public void czy_dostepne_deser(int id) {
        if(Menu_desert.get(id).dostep()) {
            System.out.println("Jest dostepne");
        } else {
            System.out.println("Nie jest dostepne");
        }
    }

    public void czy_dostepne_napoj(int id) {
        if(Menu_napoj.get(id).dostep()) {
            System.out.println("Jest dostepne");
        } else {
            System.out.println("Nie jest dostepne");
        }
    }



    public void wyswietlMenuDeserow() {
        for (int i = 0; i < Menu_desert.size(); i++) {
            System.out.println(Menu_desert.get(i));
        }
    }

    public void wyswietlMenuPierwszeDanie() {
        for (int i = 0; i < Menu_Pdanie.size(); i++) {
            System.out.println(Menu_Pdanie.get(i));
        }
    }


    public void wyswietlMenuDrugieDanie() {
        for (int i = 0; i < Menu_Ddanie.size(); i++) {
            System.out.println(Menu_Ddanie.get(i));
        }
    }

    public void wyswietlMenuNapoje() {
        for (int i = 0; i < Menu_napoj.size(); i++) {
            System.out.println(Menu_napoj.get(i));
        }
    }


    public int dodaj_desert() {
        int index = nr;
        System.out.println("Podac nazwe");
        String nazwa = scan.nextLine();
        System.out.println("Podac opis");
        String opis = scan.nextLine();
        System.out.println("Podac cene");
        double cena = scan.nextDouble();
        System.out.println("Podac dostepnosc");
        boolean czydost = scan.nextBoolean();

        Desert des1 = new Desert(index, nazwa, opis, cena, czydost);


        Menu_desert.add(des1);

        nr++;
        return index;
    }

    public int dodaj_pierwszeDanie() {
        int index = nr;
        System.out.println("Podac nazwe");
        String nazwa = scan.nextLine();
        System.out.println("Podac opis");
        String opis = scan.nextLine();
        System.out.println("Podac cene");
        double cena = scan.nextDouble();
        System.out.println("Podac dostepnosc");
        boolean czydost = scan.nextBoolean();
        PierwszeDanie pD1 = new PierwszeDanie(index, nazwa, opis, cena, czydost);

        Menu_Pdanie.add(pD1);

        nr++;
        return index;
    }

    public int dodaj_drugieDanie() {
        int index = nr;
        System.out.println("Podac nazwe");
        String nazwa = scan.nextLine();
        System.out.println("Podac opis");
        String opis = scan.nextLine();
        System.out.println("Podac cene");
        double cena = scan.nextDouble();
        System.out.println("Podac dostepnosc");
        boolean czydost = scan.nextBoolean();

        DrugieDanie drD1 = new DrugieDanie(index, nazwa, opis, cena, czydost);

        Menu_Ddanie.add(drD1);

        nr++;
        return index;
    }

    public int dodaj_napoje() {
        int index = nr;
        System.out.println("Podac nazwe");
        String nazwa = scan.nextLine();
        System.out.println("Podac opis");
        String opis = scan.nextLine();
        System.out.println("Podac cene");
        double cena = scan.nextDouble();
        System.out.println("Podac dostepnosc");
        boolean czydost = scan.nextBoolean();

        Napoje nap1 = new Napoje(index, nazwa, opis, cena, czydost);

        Menu_napoj.add(nap1);

        nr++;
        return index;
    }

    public void usun_z_Pdanie() {
        System.out.println("Usuwanie potrawy z listy Pierwszych dań" + "\n" + "Wpisz index:");
        int usun_z_menu = scan.nextInt();
        if(usun_z_menu <= Menu_Pdanie.size()-1){
            Menu_Pdanie.remove(usun_z_menu);
        } else {
            System.out.println("nie ma takiego indexu");
        }
    }

    public void usun_z_Ddanie() {
        System.out.println("Usuwanie potrawy z listy Drugich dań" + "\n" + "Wpisz index:");
        int usun_z_menu = scan.nextInt();
        if(usun_z_menu <= Menu_Ddanie.size()-1){
            Menu_Ddanie.remove(usun_z_menu);
        } else {
            System.out.println("nie ma takiego indexu");
        }
    }

    public void usun_z_Desert() {
        System.out.println("Usuwanie potrawy z listy Desertow" + "\n" + "Wpisz index:");
        int usun_z_menu = scan.nextInt();
        if(usun_z_menu <= Menu_desert.size()-1){
            Menu_desert.remove(usun_z_menu);
        } else {
            System.out.println("nie ma takiego indexu");
        }
    }

    public void usun_z_Napoje() {
        System.out.println("Usuwanie potrawy z listy Napojow" + "\n" + "Wpisz index:");
        int usun_z_menu = scan.nextInt();
        if(usun_z_menu <= Menu_napoj.size()-1){
            Menu_napoj.remove(usun_z_menu);
        } else {
            System.out.println("nie ma takiego indexu");
        }
    }

    public ArrayList<Desert> getMenu_desert() {
        return Menu_desert;
    }

    public ArrayList<PierwszeDanie> getMenu_pdanie() {
        return Menu_Pdanie;
    }

    public ArrayList<DrugieDanie> getMenu_ddanie() {
        return Menu_Ddanie;
    }

    public ArrayList<Napoje> getMenu_napoje() {
        return Menu_napoj;
    }

}
