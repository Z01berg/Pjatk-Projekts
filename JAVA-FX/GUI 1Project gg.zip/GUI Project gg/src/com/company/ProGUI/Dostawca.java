package com.company.ProGUI;

public class Dostawca implements IPracownik{

    int id;
    String imie,nazwisko;
    int numertelf;
    double napiwek;

    public Dostawca(int id, String imie, String nazwisko, int numertelf, double napiwek){
        this.id= id;
        this.imie=imie;
        this.nazwisko=nazwisko;
        this.numertelf=numertelf;
        this.napiwek=napiwek;
    }


    @Override
    public int id() {
        return 0;
    }

    @Override
    public String imie() {
        return null;
    }

    @Override
    public String nazwisko() {
        return null;
    }

    @Override
    public int numertelf() {
        return 0;
    }

    @Override
    public double napiwek() {
        return 0;
    }
}
