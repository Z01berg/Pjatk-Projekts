package com.company.ProGUI;

import java.io.DataOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Pracowniki {

    static ArrayList<Kucharz> lista_kucharz = new ArrayList<>();
    static ArrayList<Kelner> lista_kelner = new ArrayList<>();
    static ArrayList<Dostawca> lista_dostawca = new ArrayList<>();

    static Kucharz pr1 = new Kucharz(1,"Filip","Trochcicki",880546954,0);
    static Kucharz pr2 = new Kucharz(2,"Tomek","Suchcicki",880326412,0);

    static Kelner pr3 = new Kelner(3,"Katerzyna","Zrada",880654879,0);
    static Kelner pr4 = new Kelner(4,"Kacper","Lesyk",880154785,0);

    static Dostawca pr5 = new Dostawca(5,"Nazar","Kekul",880741562,0);
    static Dostawca pr6 = new Dostawca(6,"Zahar","Zubyk",880961363,0);

    static Scanner scan = new Scanner(System.in);
    static int nr = 7;


    public static void dodajListePracownikow() {
        lista_kucharz.add(pr1);
        lista_kucharz.add(pr2);

        lista_kelner.add(pr3);
        lista_kelner.add(pr4);

        lista_dostawca.add(pr5);
        lista_dostawca.add(pr6);
    }


    public static int dodaj_kucharza() {
        int index = nr;
        System.out.println("Podac imie");
        String nazwa = scan.nextLine();
        System.out.println("Podac nazwisko");
        String nazwisko = scan.nextLine();
        System.out.println("Podac telefon");
        int telefon = scan.nextInt();
        double napiwek = 0;

        Kucharz kpr0 = new Kucharz(index, nazwa, nazwisko, telefon, napiwek);


        lista_kucharz.add(kpr0);

        nr++;
        return index;
    }


    public static int dodaj_kelner() {
        int index = nr;
        System.out.println("Podac imie");
        String nazwa = scan.nextLine();
        System.out.println("Podac nazwisko");
        String nazwisko = scan.nextLine();
        System.out.println("Podac telefon");
        int telefon = scan.nextInt();
        double napiwek = 0;

        Kelner lpr0 = new Kelner(index, nazwa, nazwisko, telefon, napiwek);


        lista_kelner.add(lpr0);

        nr++;
        return index;
    }


    public static int dodaj_dostawca() {
        int index = nr;
        System.out.println("Podac imie");
        String nazwa = scan.nextLine();
        System.out.println("Podac nazwisko");
        String nazwisko = scan.nextLine();
        System.out.println("Podac telefon");
        int telefon = scan.nextInt();
        double napiwek = 0;

        Dostawca dpr0 = new Dostawca(index, nazwa, nazwisko, telefon, napiwek);


        lista_dostawca.add(dpr0);

        nr++;
        return index;
    }



    public static void pokaz_Liste_Kucharz() {
        for (Kucharz a1 : lista_kucharz) {
            System.out.println(a1);
        }
    }

    public static void pokaz_Liste_Kelner() {
        for (Kelner a1 : lista_kelner) {
            System.out.println(a1);
        }
    }

    public static void pokaz_Liste_Dostawa() {
        for (Dostawca a1 : lista_dostawca) {
            System.out.println(a1);
        }
    }


    public static void wyswietlListaKucharz() {
        for (int i = 0; i < lista_kucharz.size(); i++) {
            System.out.println(lista_kucharz.get(i));
        }
    }

    public static void wyswietlListaKelner() {
        for (int i = 0; i < lista_kelner.size(); i++) {
            System.out.println(lista_kelner.get(i));
        }
    }

    public static void wyswietlListaDostawa() {
        for (int i = 0; i < lista_dostawca.size(); i++) {
            System.out.println(lista_dostawca.get(i));
        }
    }


    public static void usun_z_Kucharz() {
        if (lista_kucharz.size() == 1){
            System.out.println("ERROR Ostatni pracownik na tym stanowisku");
        }else {
            System.out.println("Usuwanie kucharza z listy Kucharz" + "\n" + "Wpisz index:");
            int usun_z_listy = scan.nextInt();
            lista_kucharz.remove(usun_z_listy);
        }
    }

    public static void usun_z_Kelner() {
        if (lista_kelner.size() == 1){
            System.out.println("ERROR Ostatni pracownik na tym stanowisku");
        }else {
            System.out.println("Usuwanie kelnera z listy Kelner" + "\n" + "Wpisz index:");
            int usun_z_listy = scan.nextInt();
            lista_kelner.remove(usun_z_listy);
        }
    }

    public static void usun_z_Dostawa() {
        if (lista_dostawca.size() == 1){
            System.out.println("ERROR Ostatni pracownik na tym stanowisku");
        }else {
            System.out.println("Usuwanie dostawce z listy Dostawca" + "\n" + "Wpisz index:");
            int usun_z_listy = scan.nextInt();
            lista_dostawca.remove(usun_z_listy);
        }
    }

    public ArrayList<Kucharz> getLista_kucharz() {
        return lista_kucharz;
    }

    public ArrayList<Kelner> getLista_kelner() {
        return lista_kelner;
    }

    public ArrayList<Dostawca> getLista_dostawa() {
        return lista_dostawca;
    }
}
