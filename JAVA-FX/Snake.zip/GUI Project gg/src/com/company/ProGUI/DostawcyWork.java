package com.company.ProGUI;

import java.util.List;
import java.util.Objects;

public class DostawcyWork implements Runnable{
    List<Pracownicy> zaloga = Restaurant.getZaloga();
    List<Zamowienia> listaZamowien = Restaurant.getListaZamowien();
    private static int idDostawcy;

    @Override
    public void run() {
        while(true) {
                for (int i = 0; i < listaZamowien.size(); i++) {
                    if(zaloga.get(idDostawcy).getDostawcyStatus() == DostawcyStatus.wolny){
                        if(listaZamowien.get(i).getStatusZamowienia() == StatusZamowienia.dostawa){
                            zaloga.get(idDostawcy).setDostawcyStatus(DostawcyStatus.wyjechal);
                            try {
                                Thread.sleep(100);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            listaZamowien.get(i).setStatusZamowienia(StatusZamowienia.zrealizowane);
                            zaloga.get(idDostawcy).setDostawcyStatus(DostawcyStatus.wolny);
                        }
                    }
                }
            }
        }

    public static void setIdDostawcy(int idDostawcy) {
        DostawcyWork.idDostawcy = idDostawcy;
    }

    public static int getIdDostawcy() {
        return idDostawcy;
    }
}
