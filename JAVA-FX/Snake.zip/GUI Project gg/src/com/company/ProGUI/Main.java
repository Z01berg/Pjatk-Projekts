package com.company.ProGUI;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Main {
    static List<Dania> menu = new ArrayList<>();

    public static void main(String[] args) {
        menu.add(new Dania(menu.size(),"kebab z kurczakiem","pita zawinieta z kurczakiem i mieszanka warzyw",15.00,"Glowne danie",true));
        menu.add(new Dania(menu.size(),"kebab z baranina","pita zawienieta z baranina i mieszanka warzyw",16.00,"Glowne danie",true));
        menu.add(new Dania(menu.size(),"baklawa","turecki deser na bazie ciasta i miodu, bardzo slodnie",6.00,"Deser",true));
        menu.add(new Dania(menu.size(),"Coca-Cola","napoj Coca-Cola",5.00,"Napoj",true));
        menu.add(new Dania(menu.size(),"chłodnik","zimna zupa na bazie jogurtu i burakow",12.00,"Zupa",true));

        Scanner scanner = new Scanner(System.in);
        System.out.println("Chcesz rozpoczac prace restauracji ? napisz tak");
        String answer = scanner.nextLine();
        if(Objects.equals(answer, "tak")) {
            Restaurant restaurant = new Restaurant();
            Thread thread = new Thread(restaurant);
            thread.start();
        }else{
            System.out.println("Zle wprowadzone dane");
        }
    }

    public static List<Dania> getMenu() {
        return menu;
    }
}
