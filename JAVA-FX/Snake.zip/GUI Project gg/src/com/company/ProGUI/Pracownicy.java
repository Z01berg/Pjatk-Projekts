package com.company.ProGUI;

public class Pracownicy {
    private int id;
    private int numerTelefonu;
    private int Napiwek;
    private String imie;
    private String nazwisko;
    private String stanowisko;
    private DostawcyStatus dostawcyStatus;

    public Pracownicy(int id, int numerTelefonu, int napiwek, String imie, String nazwisko, String stanowisko) {
        this.id = id;
        this.numerTelefonu = numerTelefonu;
        Napiwek = napiwek;
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.stanowisko = stanowisko;
    }

    public int getId() {
        return id;
    }

    public String getStanowisko() {
        return stanowisko;
    }

    public DostawcyStatus getDostawcyStatus() {
        return dostawcyStatus;
    }

    public void setDostawcyStatus(DostawcyStatus dostawcyStatus) {
        this.dostawcyStatus = dostawcyStatus;
    }
}
