package com.company.ProGUI;

import java.util.List;
import java.util.Objects;

public class Work implements Runnable{
    List<Pracownicy> zaloga = Restaurant.getZaloga();
    List<Zamowienia> listaZamowien = Restaurant.getListaZamowien();

    @Override
    public void run() {
        while (true) {
            int liczbaKucharzy = 0;
            for (int i = 0; i < zaloga.size(); i++) {
                if(Objects.equals(zaloga.get(i).getStanowisko(), "kucharz")) {
                    liczbaKucharzy ++;
                }
            }
            if(liczbaKucharzy > 0) {
                for (int i = 0; i < listaZamowien.size(); i++) {
                    if(listaZamowien.get(i).getStatusZamowienia() == StatusZamowienia.realizacja){
                        try {
                            Thread.sleep(30000/liczbaKucharzy);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        if(listaZamowien.get(i).getAdressDostawy() != null){
                            listaZamowien.get(i).setStatusZamowienia(StatusZamowienia.dostawa);
                        } else {
                            listaZamowien.get(i).setStatusZamowienia(StatusZamowienia.zrealizowane);
                        }
                    }
                }
            }
        }
    }
}
