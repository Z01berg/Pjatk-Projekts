package com.company.ProGUI;

public class Dania {
    private int idDania;
    private String nazwaDania;
    private String opisDania;
    private String rodzajDania;
    private double cenaDania;
    private boolean dostepnosc;

    public Dania(int idDania, String nazwaDania, String opisDania, double cenaDania , String rodzajDania, boolean dostepnosc) {
        this.idDania = idDania;
        this.nazwaDania = nazwaDania;
        this.opisDania = opisDania;
        this.cenaDania = cenaDania;
        this.rodzajDania = rodzajDania;
        this.dostepnosc = dostepnosc;
    }


    public int getIdDania() {
        return idDania;
    }

    public String getNazwaDania() {
        return nazwaDania;
    }

    public void setNazwaDania(String nazwaDania) {
        this.nazwaDania = nazwaDania;
    }

    public String getOpisDania() {
        return opisDania;
    }

    public void setOpisDania(String opisDania) {
        this.opisDania = opisDania;
    }

    public double getCenaDania() {
        return cenaDania;
    }

    public void setCenaDania(double cenaDania) {
        this.cenaDania = cenaDania;
    }

    public boolean isDostepnosc() {
        return dostepnosc;
    }

    public void setDostepnosc(boolean dostepnosc) {
        this.dostepnosc = dostepnosc;
    }

    public String getRodzajDania() {
        return rodzajDania;
    }

    @Override
    public String toString() {
        return  '\n'+"░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░"+'\n'+
                "IdDania=" + idDania + '\n' +
                "NazwaDania='" + nazwaDania + '\n' +
                "OpisDania='" + opisDania + '\n' +
                "RodzajDania='" + rodzajDania + '\n' +
                "CenaDania=" + cenaDania + '\n' +
                "Dostepnosc=" + dostepnosc;
    }
}
