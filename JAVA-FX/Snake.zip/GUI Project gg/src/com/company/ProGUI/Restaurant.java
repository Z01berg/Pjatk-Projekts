package com.company.ProGUI;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Restaurant implements Runnable {
    static List<Dania> menu = Main.getMenu();
    static List<Zamowienia> listaZamowien = new ArrayList<>();
    static List<Pracownicy> zaloga = new ArrayList<>();
    Scanner scanner = new Scanner(System.in);
    Scanner scannerOpcja = new Scanner(System.in);
    File menuPlik = new File("menu.txt");
    static List<DostawcyWork> dostawcyWork = new ArrayList<>();
    static List<Thread> threads = new ArrayList<>();
    static Work work = new Work();
    static Thread thread = new Thread(work);


    public static List<Dania> getMenu() {
        return menu;
    }


    public static List<Pracownicy> getZaloga() {
        return zaloga;
    }

    public static List<Zamowienia> getListaZamowien() {
        return listaZamowien;
    }

    @Override
    public void run() {
        dodawaniePracownikow();
        while (true) {
            try {
                Thread.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //if(menuPlik.exists()){

            //} else {
            for (int i = 0; i < menu.size(); i++) {
                try {
                    FileWriter fileWriter = new FileWriter(menuPlik);
                    fileWriter.write("MENU");
                    fileWriter.write("\n");
                    fileWriter.write("\n");
                    fileWriter.write("Glowne dania");
                    for (int j = 0; j < menu.size(); j++) {
                        if (Objects.equals(menu.get(j).getRodzajDania(), "Glowne danie")) {
                            fileWriter.write("\n");
                            fileWriter.write("\n");
                            fileWriter.write(menu.get(j).toString());
                            fileWriter.write("\n");
                            fileWriter.write("\n");
                        }
                    }
                    fileWriter.write("\n");
                    fileWriter.write("\n");
                    fileWriter.write("Zupy");
                    for (int j = 0; j < menu.size(); j++) {
                        if (Objects.equals(menu.get(j).getRodzajDania(), "Zupa")) {
                            fileWriter.write("\n");
                            fileWriter.write("\n");
                            fileWriter.write(menu.get(j).toString());
                            fileWriter.write("\n");
                            fileWriter.write("\n");
                        }
                    }
                    fileWriter.write("\n");
                    fileWriter.write("\n");
                    fileWriter.write("Desery");
                    for (int j = 0; j < menu.size(); j++) {
                        if (Objects.equals(menu.get(j).getRodzajDania(), "Deser")) {
                            fileWriter.write("\n");
                            fileWriter.write("\n");
                            fileWriter.write(menu.get(j).toString());
                            fileWriter.write("\n");
                            fileWriter.write("\n");
                        }
                    }
                    fileWriter.write("\n");
                    fileWriter.write("\n");
                    fileWriter.write("Napoje");
                    for (int j = 0; j < menu.size(); j++) {
                        if (Objects.equals(menu.get(j).getRodzajDania(), "Napoj")) {
                            fileWriter.write("\n");
                            fileWriter.write("\n");
                            fileWriter.write(menu.get(j).toString());
                            fileWriter.write("\n");
                            fileWriter.write("\n");
                        }
                    }
                    fileWriter.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("1 - Dodaj zamowienie dostawa");
            System.out.println("2 - Dodaj zamowienie na miejscu");
            System.out.println("3 - Usun produkt z menu");
            System.out.println("4 - Dodaj produkt do menu");
            System.out.println("5 - Dodaj pracownika");
            System.out.println("6 - Usun pracownika");
            System.out.println("7 - Zmien dostepnosc produktu w menu");
            System.out.println("8 - Sprawdz dostepnosc produktu w menu");
            System.out.println("9 - Wyswietl liste zamowien");
            System.out.println("10 - Wyswiwetl utarg");
            System.out.println("11 - Zatrzymaj prace restauracji");
            int opcja = scannerOpcja.nextInt();
            if (opcja == 1) {
                System.out.println("Podaj adres zamowienia");
                String adres = scanner.nextLine();
                Zamowienia zamowienie = new Zamowienia(listaZamowien.size(), adres);
                listaZamowien.add(zamowienie);
                LocalTime localTime = LocalTime.now();
                listaZamowien.get(listaZamowien.size()-1).setLocalTime(localTime);
                System.out.println("Ile produktow dodac do zamowienia ?");
                int liczbaProduktow = scanner.nextInt();
                int[] pordukty = new int[liczbaProduktow];
                for (int i = 0; i < pordukty.length; i++) {
                    if (i == 0) {
                        System.out.println("Podaj index produktu :");
                        pordukty[i] = scanner.nextInt();
                    } else {
                        System.out.println("Podaj index kolejnego produktu :");
                        pordukty[i] = scanner.nextInt();
                    }
                }
                listaZamowien.get(listaZamowien.size() - 1).obliczCeneZamowienia(pordukty);
                listaZamowien.get(listaZamowien.size() - 1).setStatusZamowienia(StatusZamowienia.realizacja);
            }
            if (opcja == 2) {
                System.out.println("Podaj numer stolika");
                int numerStolika = scanner.nextInt();
                Zamowienia zamowienie = new Zamowienia(listaZamowien.size(), numerStolika);
                listaZamowien.add(zamowienie);
                LocalTime localTime = LocalTime.now();
                listaZamowien.get(listaZamowien.size()-1).setLocalTime(localTime);
                System.out.println("Ile produktow dodac do zamowienia ?");
                int liczbaProduktow = scanner.nextInt();
                int[] pordukty = new int[liczbaProduktow];
                for (int i = 0; i < pordukty.length; i++) {
                    if (i == 0) {
                        System.out.println("Podaj index produktu :");
                        pordukty[i] = scanner.nextInt();
                    } else {
                        System.out.println("Podaj index kolejnego produktu :");
                        pordukty[i] = scanner.nextInt();
                    }
                }
                listaZamowien.get(listaZamowien.size() - 1).obliczCeneZamowienia(pordukty);
            }
            if (opcja == 3) {
                System.out.println("Podaj id produktu ktory chcesz usunac");
                int idProduktu = scanner.nextInt();
                menu.remove(idProduktu);
            }
            if (opcja == 4) {
                System.out.println("Podaj nazwe produktu");
                String nazwaProduktu = scanner.nextLine();
                System.out.println("Podaj opis produktu");
                String opisProduktu = scanner.nextLine();
                System.out.println("Podaj rodzaj produktu : Napoj, Deser, Glowne danie, Zupa");
                String rodzajProduktu = scanner.nextLine();
                System.out.println("Podaj cene produktu");
                double cenaProduktu = scanner.nextDouble();
                System.out.println("Podaj dostepnosc produktu: true - jest dostepny, false - nie jest dostepny");
                boolean dostepnoscProduktu = scanner.hasNext();
                Dania dania = new Dania(menu.get(menu.size() - 1).getIdDania() + 1, nazwaProduktu, opisProduktu, cenaProduktu, rodzajProduktu, dostepnoscProduktu);
                menu.add(dania);
            }
            if (opcja == 5) {
                System.out.println("Podaj numer telefonu do pracownika");
                int numerTelefonu = scanner.nextInt();
                System.out.println("Podaj imie pracownika");
                String imie = scanner.nextLine();
                System.out.println("Podaj nazwisko pracownika");
                String nazwisko = scanner.nextLine();
                System.out.println("Podaj stanowisko pracownika, wpisz : kucharz, dostawca, kelner");
                String stanowisko = scanner.nextLine();
                Pracownicy pracownicy = new Pracownicy(zaloga.get(zaloga.size() - 1).getId() + 1, numerTelefonu, 0, imie, nazwisko, stanowisko);
                zaloga.add(pracownicy);
                if (Objects.equals(stanowisko, "dostawca")) {
                    zaloga.get(zaloga.size() - 1).setDostawcyStatus(DostawcyStatus.wolny);
                    dostawcyWork.add(new DostawcyWork());
                    dostawcyWork.get(dostawcyWork.size()-1).setIdDostawcy(pracownicy.getId());
                    threads.add(new Thread(dostawcyWork.get(dostawcyWork.size() - 1)));
                    threads.get(threads.size() - 1).start();
                }
            }
            if (opcja == 6) {
                System.out.println("Podaj id pracownika, ktorego chcesz usunac");
                int id = scanner.nextInt();
                if (zaloga.get(id).getDostawcyStatus() != null) {
                    for (int i = 0; i < dostawcyWork.size(); i++) {
                        int idDostawcy = DostawcyWork.getIdDostawcy();
                        if (idDostawcy == id) {
                            threads.get(i).stop();
                            threads.remove(i);
                            dostawcyWork.remove(i);
                            zaloga.remove(id);
                            break;
                        }
                    }
                } else {
                    zaloga.remove(id);
                }
            }
            if (opcja == 7) {
                System.out.println("Podaj id produktu dla ktorego chcesz zmienic dostepnosc");
                int idProduktu = scanner.nextInt();
                menu.get((idProduktu)).setDostepnosc(!menu.get(idProduktu).isDostepnosc());
            }
            if (opcja == 8) {
                System.out.println("Podaj id produktu dla ktorego chcesz sprawdzic dostepnosc");
                int idProduktu = scanner.nextInt();
                System.out.println("true - jest dostepny");
                System.out.println("false - nie jest dostepny");
                System.out.println(menu.get(idProduktu).isDostepnosc());
            }
            if (opcja == 9) {
                System.out.println("jakich zamowien chcesz liste ? Wpisz : zrealizowane, dostawa, realizacja");
                String odpowiedz = scanner.nextLine();
                if(Objects.equals(odpowiedz, "zrealizowane")){
                    for (int i = 0; i < listaZamowien.size(); i++) {
                        if(listaZamowien.get(i).getStatusZamowienia() == StatusZamowienia.zrealizowane){
                            System.out.println(listaZamowien.get(i).toString());
                        }
                    }
                }
                if(Objects.equals(odpowiedz, "dostawa")){
                    for (int i = 0; i < listaZamowien.size(); i++) {
                        if(listaZamowien.get(i).getStatusZamowienia() == StatusZamowienia.dostawa){
                            System.out.println(listaZamowien.get(i).toString());
                        }
                    }
                }
                if(Objects.equals(odpowiedz, "realizacja")){
                    for (int i = 0; i < listaZamowien.size(); i++) {
                        if(listaZamowien.get(i).getStatusZamowienia() == StatusZamowienia.realizacja){
                            System.out.println(listaZamowien.get(i).toString());
                        }
                    }
                }
            }
            if (opcja == 10) {
                double utarg = 0;
                for (int i = 0; i < listaZamowien.size(); i++) {
                    utarg = utarg + listaZamowien.get(i).getCenaZamowienia();
                }
                System.out.println("Utarg z dziś to : " + utarg);
            }
            if (opcja == 11) {
                Thread.currentThread().stop();
            }
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void dodawaniePracownikow(){
        Pracownicy kucharz1 = new Pracownicy(0,205334112,0,"Jan","Kowalski","kucharz");
        zaloga.add(kucharz1);
        Pracownicy kucharz2 = new Pracownicy(1,997112997,0,"Janusz","Passat","kucharz");
        zaloga.add(kucharz2);
        Pracownicy kelner = new Pracownicy(2,112321123,0,"Piotr","Suchcicki","kelner");
        zaloga.add(kelner);
        Pracownicy dostawca = new Pracownicy(3,345678912,0,"Genowefa","Cipowlaz","dostawca");
        zaloga.add(dostawca);
        zaloga.get(zaloga.size()-1).setDostawcyStatus(DostawcyStatus.wolny);
        dostawcyWork.add(new DostawcyWork());
        dostawcyWork.get(dostawcyWork.size()-1).setIdDostawcy(dostawca.getId());
        threads.add(new Thread(dostawcyWork.get(dostawcyWork.size()-1)));
        threads.get(threads.size()-1).start();
        thread.start();
        Zamowienia zamowienia1 = new Zamowienia(0,2);
        Zamowienia zamowienia2 = new Zamowienia(1,3);
        Zamowienia zamowienia3 = new Zamowienia(2,"lol");
        Zamowienia zamowienia4 = new Zamowienia(3,4);
        Zamowienia zamowienia5 = new Zamowienia(4,5);
        Zamowienia zamowienia6 = new Zamowienia(5,7);
        Zamowienia zamowienia7 = new Zamowienia(6,10);
        Zamowienia zamowienia8 = new Zamowienia(7,9);
        Zamowienia zamowienia9 = new Zamowienia(8,15);
        Zamowienia zamowienia10 = new Zamowienia(9,12);

        listaZamowien.add(zamowienia1);
        listaZamowien.add(zamowienia2);
        listaZamowien.add(zamowienia3);
        listaZamowien.add(zamowienia4);
        listaZamowien.add(zamowienia5);
        listaZamowien.add(zamowienia6);
        listaZamowien.add(zamowienia7);
        listaZamowien.add(zamowienia8);
        listaZamowien.add(zamowienia9);
        listaZamowien.add(zamowienia10);

        listaZamowien.get(0).setStatusZamowienia(StatusZamowienia.realizacja);
        listaZamowien.get(1).setStatusZamowienia(StatusZamowienia.realizacja);
        listaZamowien.get(2).setStatusZamowienia(StatusZamowienia.realizacja);
        listaZamowien.get(3).setStatusZamowienia(StatusZamowienia.realizacja);
        listaZamowien.get(4).setStatusZamowienia(StatusZamowienia.realizacja);
        listaZamowien.get(5).setStatusZamowienia(StatusZamowienia.realizacja);
        listaZamowien.get(6).setStatusZamowienia(StatusZamowienia.realizacja);
        listaZamowien.get(7).setStatusZamowienia(StatusZamowienia.realizacja);
        listaZamowien.get(8).setStatusZamowienia(StatusZamowienia.realizacja);
        listaZamowien.get(9).setStatusZamowienia(StatusZamowienia.realizacja);
    }
}
