package com.company.ProGUI;

public enum StatusZamowienia {
    realizacja,
    dostawa,
    zrealizowane
}
