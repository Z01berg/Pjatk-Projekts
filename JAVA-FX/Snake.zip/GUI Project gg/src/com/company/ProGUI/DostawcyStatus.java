package com.company.ProGUI;

public enum DostawcyStatus {
    wyjechal,
    wolny
}
