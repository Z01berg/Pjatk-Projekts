package com.company.ProGUI;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class Zamowienia {
    private int idZamowienia;
    private int numerStolika;
    private static String adressDostawy;
    private List<Dania> menu = Restaurant.getMenu();
    private double cenaZamowienia;
    private StatusZamowienia statusZamowienia;
    static LocalTime localTime;

    public Zamowienia(int idZamowienia, String adressDostawy) {
        this.idZamowienia = idZamowienia;
        this.adressDostawy = adressDostawy;
    }

    public Zamowienia(int idZamowienia, int numerStolika) {
        this.idZamowienia = idZamowienia;
        this.numerStolika = numerStolika;
    }

    public void obliczCeneZamowienia(int idProduktow[]){
        for (int j : idProduktow) {
            double cena = menu.get(j).getCenaDania();
            cenaZamowienia = cenaZamowienia + cena;
        }
    }

    public double getCenaZamowienia() {
        return cenaZamowienia;
    }

    public void setStatusZamowienia(StatusZamowienia statusZamowienia) {
        this.statusZamowienia = statusZamowienia;
    }

    public StatusZamowienia getStatusZamowienia() {
        return statusZamowienia;
    }

    public static void setLocalTime(LocalTime localTime) {
        Zamowienia.localTime = localTime;
    }

    public static String getAdressDostawy() {
        return adressDostawy;
    }

    @Override
    public String toString() {
        return  '\n'+"▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄"+'\n'+
                "Zamowienia{" +
                "idZamowienia=" + idZamowienia +
                ", numerStolika=" + numerStolika +
                ", adressDostawy='" + adressDostawy + '\'' +
                ", menu=" + menu +
                ", cenaZamowienia=" + cenaZamowienia +
                ", statusZamowienia=" + statusZamowienia +
                "czas zamowienia" + localTime +
                '}'+'\n'+"▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀";
    }
}
