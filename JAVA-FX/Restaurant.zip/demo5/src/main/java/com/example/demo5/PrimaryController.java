package com.example.demo5;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Pane;

import java.io.*;

public class PrimaryController {

    @FXML
    Pane panic;
    @FXML
    ScrollPane score2;

    public void visiblesc () throws IOException{

        score2.setVisible(!score2.isVisible());
    }

    public void visibleS () throws IOException{

        panic.setVisible(!panic.isVisible());
    }

    public void tosec () throws IOException {

        App.setRoot("snake");

    }



    public void close() throws  IOException{

        Platform.exit();
    }

    public void read () throws FileNotFoundException {
        File Hightscore = new File("score.txt");
        FileReader H = new FileReader("score.txt");
    }
    public void write() {
        //try {
          //  FileWriter fileWriter = new FileWriter(Hightscore);
       // } catch (IOException e) {
           // e.printStackTrace();
        //}
    }

   // MyView(Kontroler kontroler){
//
   // }

}
